const config = { 
//------------Connections-----------//
    Client_Token: 'ODg3OTkwNTE4NjE5OTg4MDA5.YUMLnQ.e6MPjrVIvhm3FzRSHwjgIj4A1Ew',
    MongoDB_ConnectURL: 'mongodb+srv://rowie:rowie@cluster0.pj7cv.mongodb.net/rowie?retryWrites=true&w=majority',
    //------------BotSettings-----------//
    Prefix: '!',
    BotOwners: ["846373479129153536"],
    Custom_Status_Text: 'Xeno ❤️ Vienna',
    Custom_Status_Type: 'PLAYING', // => PLAYING / WATCHING / LISTENING
    Custom_Status: 'Xeno', // => dnd / idle / online / invisible
    VoiceChannelID: ''
};
  
module.exports = config;
