# rowie-main
rowie türemesinin kullandığı botlar

bir tek moderasyon botu yok kullandığı modda ibidinin paylaştığı owslacık botu :)

https://github.com/RowieAyaz şunuda ekleyek xrd yeni hesabıda bu https://github.com/Alencia
