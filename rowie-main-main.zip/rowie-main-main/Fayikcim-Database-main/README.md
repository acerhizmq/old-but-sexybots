# Fayikcim-Database

Herkese merhabalar!

Eskiden kullandığım databse botunu sizlere sunuyorum herkese iyi kodlamalar.

index.js de config yerini doldurup botu kullanamaya başlıyabilirsiniz.
