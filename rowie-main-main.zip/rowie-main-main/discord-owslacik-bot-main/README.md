# owslacik-bot

DEMEK ARKADAŞIMIZ TÜRKİYEDE İLK YAPIYORMUŞ BU SİSTEMİ ATLANTİS'TE TOASTY KULLANIYOR VE ONU BİLE BİLE
BASTIRA BASTIRA ÖZENTİLERE SELAM VERMESİ ÇOK HOŞ BİR DURUM DEĞİL. 
discord.gg/darkparadise botlarına bu repodan ulaşabilirsiniz <3
