# v14-ozel-oda-sistemi
- Soru ve bot hakkında sorunlar için:  `luhux#1847`

```bash
> Discord özel oda sistemi
```

# Görseller
![image](https://user-images.githubusercontent.com/74924310/209652325-2e14ec09-797b-4814-b1c2-9603ab643c32.png)<br>
![image](https://user-images.githubusercontent.com/74924310/209652330-b6d825a8-1cdb-4c56-bdbe-971271622691.png)<br>
![image](https://user-images.githubusercontent.com/74924310/209652360-a770aa4f-a36d-4f55-825a-aa733f31d353.png)<br>
![image](https://user-images.githubusercontent.com/74924310/209652368-c93ba2d0-ce4a-4865-b10a-6953dae2a444.png)<br>
![image](https://user-images.githubusercontent.com/74924310/209652380-0f81e7cd-6d79-466f-bb7f-6b40c0d423fa.png)<br>
