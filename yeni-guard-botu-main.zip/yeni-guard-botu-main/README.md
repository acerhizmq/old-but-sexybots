# Guard botu
* paylaşmayın mit lisansı var saygılar sevgiler kullanın

# Kurulum
* config doldur yeter

# İletişim
* [Discord Profilim](https://discord.com/users/403820625530978304)
* Herhangi bir hata bulmanız durumunda ya da yardım isteyeceğiniz zaman buralardan bana ulaşabilirsiniz.
