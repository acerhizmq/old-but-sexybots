# Kapsent-Bots

# Kapsentin aristen alıp editlediği botu yaptım birazdan buraya atacam bana hiç bir şey bilmiyorsun diyor ama kendisi bot editliyor her neyse sadece chat gaurd mute limit eklemedim oda üşendim çok fazla uraşmak istemedim setup bire bir aynı onun botla zaten dediğim gibi aris botu alıp editlemiş atıcam birazdan alın hayrını görün ssler de koyarım alta Aynen Kapsent Abisi hiç bir şey bilmiyorum onun botunun aynisini yapinca herseyini atarim chat guard falan yani şimdi uraşmak istemedim
![image](https://cdn.discordapp.com/attachments/1001567119344926740/1016679611154841690/setup_configi.png)
![image](https://cdn.discordapp.com/attachments/1001567119344926740/1016506602989305856/config.png)
![image](https://cdn.discordapp.com/attachments/1001567119344926740/1016681510201466890/say_kapsent.png)
![image](https://cdn.discordapp.com/attachments/1001567119344926740/1016678857056722974/kapsent_log_kurma.png)

