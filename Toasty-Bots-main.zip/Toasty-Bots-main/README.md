# Toasty-Bots Zadee#1915

Toasty'nin atlantis sunucusunda kullandığı tüm botları burada paylaşıp egolarını kendilerine yedirme vol 1
**Stat Botu**


![image](https://user-images.githubusercontent.com/77938499/121361655-2c1a2b80-c93e-11eb-8536-dac1b8979317.png)

![image](https://user-images.githubusercontent.com/77938499/121361700-376d5700-c93e-11eb-97b4-8e2020c81e41.png)

![image](https://user-images.githubusercontent.com/77938499/121361741-3dfbce80-c93e-11eb-912d-3849c83851c4.png)

![image](https://user-images.githubusercontent.com/77938499/121361507-0725b880-c93e-11eb-97ac-237e932f75dd.png)

![image](https://user-images.githubusercontent.com/77938499/121361541-0e4cc680-c93e-11eb-9b96-bdd065287221.png)

**Moderasyon Botu**
![image](https://user-images.githubusercontent.com/77938499/121362767-06415680-c93f-11eb-9991-f9b86a72b3cc.png)

![image](https://user-images.githubusercontent.com/77938499/121363814-f118f780-c93f-11eb-9a92-3bb96c94d0e9.png)

![image](https://user-images.githubusercontent.com/77938499/121363840-f5ddab80-c93f-11eb-8031-227230ddd39d.png)

![image](https://user-images.githubusercontent.com/77938499/121364026-17d72e00-c940-11eb-807b-121de281333e.png)

![image](https://user-images.githubusercontent.com/77938499/121389547-3267d200-c955-11eb-9364-e990f6918b4a.png)


![image](https://user-images.githubusercontent.com/77938499/121362282-aa76cd80-c93e-11eb-9288-9ae9714b115c.png)

![image](https://user-images.githubusercontent.com/77938499/121362334-b4003580-c93e-11eb-97a0-d551aa730d98.png)


**Guard Botu**
![image](https://user-images.githubusercontent.com/77938499/121354397-8368cd80-c937-11eb-987a-a601b260d023.png)

![image](https://user-images.githubusercontent.com/77938499/121354429-8b287200-c937-11eb-88df-521b8d744326.png)

**İnvite Botu**
![image](https://user-images.githubusercontent.com/77938499/121364573-93d17600-c940-11eb-816b-86c7feba5f21.png)


![image](https://user-images.githubusercontent.com/77938499/121364494-80bea600-c940-11eb-92db-3dd88a69affa.png)
