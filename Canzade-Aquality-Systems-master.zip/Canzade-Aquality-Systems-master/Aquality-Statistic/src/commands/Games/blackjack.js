const Discord = require("discord.js");
const oyun = require("../../models/game");

module.exports = {
	conf: {
		name: "blackjack",
		usage: "bj",
		category: "Global",
		description: "Blackjack oynarsınız.",
		aliases: ["bj"],
	},

	async run(client, message, args) {},
};
