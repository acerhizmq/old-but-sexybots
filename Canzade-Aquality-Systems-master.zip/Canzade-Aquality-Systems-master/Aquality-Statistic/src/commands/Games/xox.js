const Discord = require("discord.js");
const oyun = require("../../models/game");
module.exports = {
	conf: {
		name: "xox",
		usage: "bj",
		category: "Global",
		description: "xox oynarsınız.",
		aliases: ["tictactoe", "tic-tac-toe"],
	},

	async run(client, message, args) {
		
	},
};
