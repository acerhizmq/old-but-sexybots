# Canzade-Aquality-Systems
Uzun bir süre beklettiğim için üzgünüm. Botun tüm içeriğinin aquality botları olması yerine aqualityde olan sistemler ile kendi yorumlarımı birleştirdim ortaya daha güzel bir iş çıktığına eminim. Guard botunu şuan için paylaşmayacağım talep artarsa paylaşacağım.
Kurulumları tamamlamak için tüm botların config dosyasını doldurduktan sonra moderasyon botunu başlatıp .setup komutu ile bütün kurulumları bitirmeniz gerekiyor. Bütün botların stabil çalışması için tüm botlarda aynı mongoDB linkini kullanmanız gerekiyor. Hata ile karışmanız durumunda benimle iletişime geçin Discord: canzade

Kodlar şahsım tarafından yazılmıştır.
Aquality botçucusu AreBy botların replikasını paylaşmama izin verdiği için teşekkür ederim.

![image](https://worker.canzade.rocks/storage/uploads/gifs/451148936753840128.gif)

# STAT BOTU
![image](https://worker.canzade.rocks/storage/uploads/images/451146220526764032.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451123664323215368.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451465638356058113.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451123081050718212.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451123142346276869.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451130659004612608.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451136424763326464.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451136739105439746.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451139916013895683.png)

# SYNC BOTU
![image](https://worker.canzade.rocks/storage/uploads/images/451139200209780736.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451139501755072514.png)

# 216 BOTU
![image](https://worker.canzade.rocks/storage/uploads/images/451138655814287360.png)

# INVITE BOTU
![image](https://worker.canzade.rocks/storage/uploads/images/451140470446358528.png)

# MODERATION BOTU
![image](https://worker.canzade.rocks/storage/uploads/images/451142191134408709.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451142783856672770.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451143519357239301.png)
![image](https://worker.canzade.rocks/storage/uploads/images/451144516053893120.png)
![image](https://user-images.githubusercontent.com/77938499/184345051-f65c7291-8f1b-4a2d-a5c9-2cd022a7fb7b.png)
![image](https://user-images.githubusercontent.com/77938499/184353463-59303c61-4f88-49fb-9a8d-7292fb09592e.png)
![image](https://user-images.githubusercontent.com/77938499/184345233-dd855a95-df34-4da6-874f-35fbec7ed180.png)
![image](https://user-images.githubusercontent.com/77938499/184345298-973ec70d-0d96-4337-8e21-0213843f62a6.png)
![image](https://user-images.githubusercontent.com/77938499/184345362-f688c823-0a10-4a6d-8603-84a59375a7ef.png)
![image](https://user-images.githubusercontent.com/77938499/184345409-6a09b8a7-d1ff-469e-8056-3fc5faacfa33.png)
![image](https://user-images.githubusercontent.com/77938499/184345651-068ee4d3-22de-4cfd-8be2-11b5c8a9e1f6.png)
![image](https://user-images.githubusercontent.com/77938499/184345685-dcd3c03e-ee03-4ec7-935c-db8a4eeac12d.png)
![image](https://user-images.githubusercontent.com/77938499/184347235-6e900a38-c680-4d35-9cbb-d3baec34656d.png)
![image](https://user-images.githubusercontent.com/77938499/184347318-368d9242-d42a-4b1a-94f8-eaaaad366da7.png)
![image](https://user-images.githubusercontent.com/77938499/184348159-366c7837-51a3-4552-9847-14a0dd5cb8d0.png)




