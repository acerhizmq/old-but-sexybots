﻿const CONFIG = {
	BOT_TOKEN:
		"",
	MONGO_URL:
		"",
	PREFIX: ["!", "."],
	BOT_VOICE_CHANNEL: "1013200755970289782",
	BOT_STATUS: ["canzade ❤️ Labirent", "Labirent ❤️ canzade"],
	GUILD_ID: "1013200754523258910",

	emojis: {
		yes_name: "yes_zade",
		no_name: "no_zade",
	},
};

module.exports = CONFIG;
