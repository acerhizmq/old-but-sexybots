﻿const CONFIG = {
	BOT_TOKEN:
		"",
	MONGO_URL:
		"",
	PREFIX: ["!", "."],
	BOT_VOICE_CHANNEL: "1013200755211124819",
	BOT_STATUS: ["canzade ❤️ Labirent", "Labirent ❤️ canzade"],
	BOT_OWNERS: ["331846231514939392", "1040358584116068433"],
	GUILD_ID: "1013200754523258910",

	emojis: {
		yes_name: "yes_zade",
		no_name: "no_zade",
	},
};

module.exports = CONFIG;
