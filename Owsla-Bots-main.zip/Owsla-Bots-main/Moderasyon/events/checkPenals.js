let sunucuayar = require("../models/sunucuayar");
let alarm = require("../models/alarm");
let muteInterval = require("../models/muteInterval");
let vmuteInterval = require("../models/vmuteInterval");
let jailInterval = require("../models/jailInterval");
let dcInterval = require("../models/dcInterval");
let vkInterval = require("../models/vkInterval");
let stInterval = require("../models/stInterval");
let tagInterval = require("../models/taglıUye");
let authorityInterval = require("../models/authority_user");
module.exports = async client => {

}