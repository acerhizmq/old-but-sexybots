module.exports = {

    MODTOKEN: "",
    STATTOKEN: "",
    MPLUSTOKEN: "",

    SECTOKENS: {
        ONE: "",
        TWO: "",
        THREE: "",
        FOUR: "",
        DISTMAIN: "",
        DISTS: [
        "",
        ""
        ]
    },

    WELCOMETOKENS: [
        "",
        "",
        "",
        "",
        "",
        "",
    ],

    WELCOMECHANNELS: [
        ""
    ],

    Webclient: {
        clientID: "",
        secret: "",
        callbackURL: "",
    },
    prefix: ".",
    prefixs: ["."],
    MongoURL: "",

    botDurum: {
        desc: "Nexus Developed by SEHIRΛ",
        type: "PLAYING",
        url: "",
    },

    botSesKanali: "938133281944252518",

    staff: [
        { id: "935539319614078986", username: "sehira#0001" },
        { id: "317518644705755138", username: "acar#0001" },

    ]
}
