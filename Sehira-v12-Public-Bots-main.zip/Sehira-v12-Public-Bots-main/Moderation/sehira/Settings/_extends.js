module.exports = {

        bakımModu: {
            MAIN: false,
            SINGLEMAIN: false,
            KOMUTLAR: [],
            BILGI: ""
        },

        sunucuID: "938133281151549520",
        sunucuURL: "1874",
        sunucuIsmi: "1874",
        yasakTaglar: [],

	      etiket: true,
        etiketTag: "1874",
        etiketRol: "938133281382219801",
        yasakEtiketler: [],

        tag: "†",
        tagsiz: "•",
        taglıalım: true,
        minYaş: "12",
        link: "discord.gg/1874",

        kufurEngel: true,
        reklamEngel: true,
        acarkre: {
          konsolBilgi: false,
          uyariMesaji: false,
          izinliKanallar: [],
          kufurUyariMesaji: "Birdaha küfür etmemelisin aksi taktirde ceza alacaksın.",
          reklamUyariMesaji: "Birdaha reklam yapmamalısın aksi taktirde ceza alacaksın."
        },

        
        embed: {
          iconURL: "https://images-ext-2.discordapp.net/external/iRBgmXX1iWoQanwY5jVnEDllSO9sjkIKiYt0ViTTFDU/https/cdn.discordapp.com/icons/858711859322159114/a_571bb27cd307619c41a1bb4f35964900.gif",
          başlık: "1874",
          altbaşlık: `1874 Developed by SEHIRΛ`,
          renk: "RANDOM"
        }

}