module.exports = {
    sistem: true,
    görevsonyetki: "898860146158096435",
    
    puanlama: {
      sistem: false,
      sesPuan: 4,
      yetkiliPuan: 25,
      invitePuan: 15,
      tagliPuan: 25,
      kayitPuan: 5.5,
    },



    yetkiler: [
	"898860153460391936",
	"898860152575385630",
	"898860151459708980",
	"898860150759260161",
	"898860149509324880",
	"898860148779524146",
	"898860147848380437",
	"898860147089244160"
    ],
    
    görevler: [
      { rol: "898860153460391936", invite: "15", taglı: "5", yetkili: "0", public: "25", kayıt: "10", genelses: "75", Ödül: true},
      { rol: "898860152575385630", invite: "10", taglı: "3", yetkili: "3", public: "25", kayıt: "0", genelses: "80", Ödül: true},
      { rol: "898860151459708980", invite: "10", taglı: "3", yetkili: "3", public: "25", kayıt: "0", genelses: "80", Ödül: true},
      { rol: "898860150759260161", invite: "10", taglı: "3", yetkili: "3", public: "25", kayıt: "0", genelses: "85", Ödül: true},
      { rol: "898860149509324880", invite: "10", taglı: "3", yetkili: "3", public: "25", kayıt: "0", genelses: "85", Ödül: true},
      { rol: "898860148779524146", invite: "10", taglı: "3", yetkili: "3", public: "25", kayıt: "0", genelses: "90", Ödül: true},
      { rol: "898860147848380437", invite: "10", taglı: "4", yetkili: "4", public: "25", kayıt: "0", genelses: "95", Ödül: true},
      { rol: "898860147089244160", invite: "15", taglı: "5", yetkili: "5", public: "30", kayıt: "0", genelses: "100", Ödül: true}
    ]
}