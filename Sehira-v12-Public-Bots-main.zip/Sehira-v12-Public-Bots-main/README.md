# Sehira-v12-Public-Bots
Acar abi yardımıyla yaptığım v12 public botunu paylaşma kararı aldım.
Bot tamamen hatasız çalışmaktadır, ayarlanıcak yerler zaten belli ayarlaryıp kullanabilirsiniz. Kendim sıfır v13 bot yapıp ona geçtiğim için paylaşıyorum. Her hangi bir soru veya bot yaptırmak için discord: sehira#0001 desteklerinden dolayı Acar abime çok teşekkür ediyorum.
Alın kullanın işte mis gibi bot aq 
